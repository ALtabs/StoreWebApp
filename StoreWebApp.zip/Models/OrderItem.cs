﻿namespace StoreWebApp.Models
{
    public class OrderItem
    {
        public int id { get; set; }
        public int siteId { get; set; }
        public int productId { get; set; }
        public string currency { get; set; }
        public string paymentMethod { get; set; }
        public decimal retailCost { get; set; }
        public decimal accountDiscount { get; set; }
        public decimal couponDiscount { get; set; }
        public decimal netCost { get; set; }
    }
}
