﻿namespace StoreWebApp.ViewModels
{
    public class OrderSummaryViewModel
    {
        public long OrderId { get; set; }
        public decimal NetPrice { get; set; }
    }
}
