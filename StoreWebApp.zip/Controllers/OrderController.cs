﻿using Microsoft.AspNetCore.Mvc;
using StoreWebApp.Models;
using StoreWebApp.ViewModels;
using System.Text.Json;

namespace StoreWebApp.Controllers
{
    public class OrderController : Controller
    {
        public IActionResult Index()
        {
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "orders.json");
            if (!System.IO.File.Exists(filePath))
            {
                return NotFound("Orders file not found.");
            }
            var json = System.IO.File.ReadAllText(filePath);
            var orders = JsonSerializer.Deserialize<List<Order>>(json) ?? new List<Order>();

            var result = orders.Select(o => new OrderSummaryViewModel
            {
                OrderId = o.id,
                NetPrice = o.items?.Sum(i => i.netCost) ?? 0
            }).ToList();

            return View(result);
        }
    }
}
