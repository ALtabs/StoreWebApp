﻿using Microsoft.AspNetCore.Mvc;
using StoreWebApp.Models;
using System.Text.Json;

namespace StoreWebApp.Controllers
{
    public class StoreController : Controller
    {
        public IActionResult Index()
        {
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "products.json");
            if (!System.IO.File.Exists(filePath))
            {
                return NotFound("Products file not found.");
            }
            var jsonData = System.IO.File.ReadAllText(filePath);
            var products = JsonSerializer.Deserialize<List<Product>>(jsonData) ?? new List<Product>();

            return View(products);
        }
    }
}
